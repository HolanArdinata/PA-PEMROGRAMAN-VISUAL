﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DataPemesanan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.btnpesan = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.total = New System.Windows.Forms.Label()
        Me.pesawat = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.pembayaran = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.bulan = New System.Windows.Forms.Label()
        Me.tahun = New System.Windows.Forms.Label()
        Me.jml = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.harga = New System.Windows.Forms.Label()
        Me.jam = New System.Windows.Forms.Label()
        Me.tgl = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.kelas = New System.Windows.Forms.Label()
        Me.telepon = New System.Windows.Forms.Label()
        Me.tujuan = New System.Windows.Forms.Label()
        Me.nama = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txttotal = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtpesawat = New System.Windows.Forms.TextBox()
        Me.cbpembayaran = New System.Windows.Forms.ComboBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtharga = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.cbkodetujuan = New System.Windows.Forms.ComboBox()
        Me.txtjam = New System.Windows.Forms.TextBox()
        Me.txttujuan = New System.Windows.Forms.TextBox()
        Me.txtkelas = New System.Windows.Forms.TextBox()
        Me.txttahun = New System.Windows.Forms.TextBox()
        Me.txtbulan = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtkode = New System.Windows.Forms.TextBox()
        Me.txttgl = New System.Windows.Forms.TextBox()
        Me.txtjumlah = New System.Windows.Forms.TextBox()
        Me.txttelepon = New System.Windows.Forms.TextBox()
        Me.txtnama = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnedit = New System.Windows.Forms.Button()
        Me.btndelete = New System.Windows.Forms.Button()
        Me.txtcari = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.btntambah = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnclear
        '
        Me.btnclear.BackColor = System.Drawing.Color.Transparent
        Me.btnclear.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclear.Location = New System.Drawing.Point(262, 458)
        Me.btnclear.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(67, 34)
        Me.btnclear.TabIndex = 13
        Me.btnclear.Text = "Clear"
        Me.btnclear.UseVisualStyleBackColor = False
        '
        'btnexit
        '
        Me.btnexit.BackColor = System.Drawing.Color.Transparent
        Me.btnexit.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(517, 458)
        Me.btnexit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(67, 34)
        Me.btnexit.TabIndex = 11
        Me.btnexit.Text = "Exit"
        Me.btnexit.UseVisualStyleBackColor = False
        '
        'btnpesan
        '
        Me.btnpesan.BackColor = System.Drawing.Color.Transparent
        Me.btnpesan.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnpesan.Location = New System.Drawing.Point(982, 889)
        Me.btnpesan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnpesan.Name = "btnpesan"
        Me.btnpesan.Size = New System.Drawing.Size(81, 34)
        Me.btnpesan.TabIndex = 10
        Me.btnpesan.Text = "Tambah"
        Me.btnpesan.UseVisualStyleBackColor = False
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(Me.total)
        Me.GroupBox2.Controls.Add(Me.pesawat)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label23)
        Me.GroupBox2.Controls.Add(Me.pembayaran)
        Me.GroupBox2.Controls.Add(Me.Label18)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label26)
        Me.GroupBox2.Controls.Add(Me.bulan)
        Me.GroupBox2.Controls.Add(Me.tahun)
        Me.GroupBox2.Controls.Add(Me.jml)
        Me.GroupBox2.Controls.Add(Me.Label22)
        Me.GroupBox2.Controls.Add(Me.harga)
        Me.GroupBox2.Controls.Add(Me.jam)
        Me.GroupBox2.Controls.Add(Me.tgl)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.kelas)
        Me.GroupBox2.Controls.Add(Me.telepon)
        Me.GroupBox2.Controls.Add(Me.tujuan)
        Me.GroupBox2.Controls.Add(Me.nama)
        Me.GroupBox2.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.GroupBox2.Location = New System.Drawing.Point(621, 337)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox2.Size = New System.Drawing.Size(499, 244)
        Me.GroupBox2.TabIndex = 8
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "[ DETAIL TIKET ]"
        '
        'total
        '
        Me.total.AutoSize = True
        Me.total.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.total.Location = New System.Drawing.Point(363, 137)
        Me.total.Name = "total"
        Me.total.Size = New System.Drawing.Size(15, 24)
        Me.total.TabIndex = 42
        Me.total.Text = "-"
        '
        'pesawat
        '
        Me.pesawat.AutoSize = True
        Me.pesawat.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.pesawat.Location = New System.Drawing.Point(363, 114)
        Me.pesawat.Name = "pesawat"
        Me.pesawat.Size = New System.Drawing.Size(15, 24)
        Me.pesawat.TabIndex = 26
        Me.pesawat.Text = "-"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label15.Location = New System.Drawing.Point(310, 137)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(54, 24)
        Me.Label15.TabIndex = 41
        Me.Label15.Text = "Total  :"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label23.Location = New System.Drawing.Point(289, 114)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(74, 24)
        Me.Label23.TabIndex = 25
        Me.Label23.Text = "Pesawat  :"
        '
        'pembayaran
        '
        Me.pembayaran.AutoSize = True
        Me.pembayaran.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.pembayaran.Location = New System.Drawing.Point(103, 203)
        Me.pembayaran.Name = "pembayaran"
        Me.pembayaran.Size = New System.Drawing.Size(15, 24)
        Me.pembayaran.TabIndex = 24
        Me.pembayaran.Text = "-"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label18.Location = New System.Drawing.Point(3, 203)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(101, 24)
        Me.Label18.TabIndex = 23
        Me.Label18.Text = "Pembayaran  :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(7, 138)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(110, 24)
        Me.Label10.TabIndex = 20
        Me.Label10.Text = "Jam                  :"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label26.Location = New System.Drawing.Point(113, 38)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(17, 24)
        Me.Label26.TabIndex = 18
        Me.Label26.Text = "/"
        '
        'bulan
        '
        Me.bulan.AutoSize = True
        Me.bulan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.bulan.Location = New System.Drawing.Point(148, 114)
        Me.bulan.Name = "bulan"
        Me.bulan.Size = New System.Drawing.Size(15, 24)
        Me.bulan.TabIndex = 17
        Me.bulan.Text = "-"
        '
        'tahun
        '
        Me.tahun.AutoSize = True
        Me.tahun.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.tahun.Location = New System.Drawing.Point(231, 114)
        Me.tahun.Name = "tahun"
        Me.tahun.Size = New System.Drawing.Size(15, 24)
        Me.tahun.TabIndex = 16
        Me.tahun.Text = "-"
        '
        'jml
        '
        Me.jml.AutoSize = True
        Me.jml.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.jml.Location = New System.Drawing.Point(103, 183)
        Me.jml.Name = "jml"
        Me.jml.Size = New System.Drawing.Size(15, 24)
        Me.jml.TabIndex = 15
        Me.jml.Text = "-"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label22.Location = New System.Drawing.Point(39, 183)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(84, 24)
        Me.Label22.TabIndex = 14
        Me.Label22.Text = "Jumlah  :    "
        '
        'harga
        '
        Me.harga.AutoSize = True
        Me.harga.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.harga.Location = New System.Drawing.Point(103, 160)
        Me.harga.Name = "harga"
        Me.harga.Size = New System.Drawing.Size(15, 24)
        Me.harga.TabIndex = 11
        Me.harga.Text = "-"
        '
        'jam
        '
        Me.jam.AutoSize = True
        Me.jam.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.jam.Location = New System.Drawing.Point(121, 139)
        Me.jam.Name = "jam"
        Me.jam.Size = New System.Drawing.Size(15, 24)
        Me.jam.TabIndex = 10
        Me.jam.Text = "-"
        '
        'tgl
        '
        Me.tgl.AutoSize = True
        Me.tgl.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.tgl.Location = New System.Drawing.Point(112, 114)
        Me.tgl.Name = "tgl"
        Me.tgl.Size = New System.Drawing.Size(15, 24)
        Me.tgl.TabIndex = 9
        Me.tgl.Text = "-"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(7, 160)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(105, 24)
        Me.Label14.TabIndex = 6
        Me.Label14.Text = "Harga/Tiket   :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label13.Location = New System.Drawing.Point(3, 137)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(14, 24)
        Me.Label13.TabIndex = 5
        Me.Label13.Text = " "
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(4, 114)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(109, 24)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = " Tanggal          :"
        '
        'kelas
        '
        Me.kelas.AutoSize = True
        Me.kelas.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.kelas.Location = New System.Drawing.Point(41, 89)
        Me.kelas.Name = "kelas"
        Me.kelas.Size = New System.Drawing.Size(15, 24)
        Me.kelas.TabIndex = 3
        Me.kelas.Text = "-"
        '
        'telepon
        '
        Me.telepon.AutoSize = True
        Me.telepon.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.telepon.Location = New System.Drawing.Point(128, 38)
        Me.telepon.Name = "telepon"
        Me.telepon.Size = New System.Drawing.Size(15, 24)
        Me.telepon.TabIndex = 2
        Me.telepon.Text = "-"
        '
        'tujuan
        '
        Me.tujuan.AutoSize = True
        Me.tujuan.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.tujuan.Location = New System.Drawing.Point(41, 64)
        Me.tujuan.Name = "tujuan"
        Me.tujuan.Size = New System.Drawing.Size(15, 24)
        Me.tujuan.TabIndex = 1
        Me.tujuan.Text = "-"
        '
        'nama
        '
        Me.nama.AutoSize = True
        Me.nama.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.nama.Location = New System.Drawing.Point(41, 38)
        Me.nama.Name = "nama"
        Me.nama.Size = New System.Drawing.Size(15, 24)
        Me.nama.TabIndex = 0
        Me.nama.Text = "-"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txttotal)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.txtpesawat)
        Me.GroupBox1.Controls.Add(Me.cbpembayaran)
        Me.GroupBox1.Controls.Add(Me.btnpesan)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.txtharga)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.cbkodetujuan)
        Me.GroupBox1.Controls.Add(Me.txtjam)
        Me.GroupBox1.Controls.Add(Me.txttujuan)
        Me.GroupBox1.Controls.Add(Me.txtkelas)
        Me.GroupBox1.Controls.Add(Me.txttahun)
        Me.GroupBox1.Controls.Add(Me.txtbulan)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.txtkode)
        Me.GroupBox1.Controls.Add(Me.txttgl)
        Me.GroupBox1.Controls.Add(Me.txtjumlah)
        Me.GroupBox1.Controls.Add(Me.txttelepon)
        Me.GroupBox1.Controls.Add(Me.txtnama)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(13, 52)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.GroupBox1.Size = New System.Drawing.Size(1109, 281)
        Me.GroupBox1.TabIndex = 7
        Me.GroupBox1.TabStop = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(508, 234)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(42, 24)
        Me.Label8.TabIndex = 40
        Me.Label8.Text = "Total"
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(560, 231)
        Me.txttotal.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.ReadOnly = True
        Me.txttotal.Size = New System.Drawing.Size(141, 29)
        Me.txttotal.TabIndex = 39
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label21.Location = New System.Drawing.Point(9, 234)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(62, 24)
        Me.Label21.TabIndex = 36
        Me.Label21.Text = "Pesawat"
        '
        'txtpesawat
        '
        Me.txtpesawat.Location = New System.Drawing.Point(161, 231)
        Me.txtpesawat.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtpesawat.Name = "txtpesawat"
        Me.txtpesawat.ReadOnly = True
        Me.txtpesawat.Size = New System.Drawing.Size(147, 29)
        Me.txtpesawat.TabIndex = 35
        '
        'cbpembayaran
        '
        Me.cbpembayaran.FormattingEnabled = True
        Me.cbpembayaran.Items.AddRange(New Object() {"Cash", "Debit"})
        Me.cbpembayaran.Location = New System.Drawing.Point(560, 187)
        Me.cbpembayaran.Margin = New System.Windows.Forms.Padding(4)
        Me.cbpembayaran.Name = "cbpembayaran"
        Me.cbpembayaran.Size = New System.Drawing.Size(140, 32)
        Me.cbpembayaran.TabIndex = 32
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(461, 192)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(89, 24)
        Me.Label19.TabIndex = 31
        Me.Label19.Text = "Pembayaran"
        '
        'txtharga
        '
        Me.txtharga.Location = New System.Drawing.Point(559, 145)
        Me.txtharga.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtharga.Name = "txtharga"
        Me.txtharga.ReadOnly = True
        Me.txtharga.Size = New System.Drawing.Size(141, 29)
        Me.txtharga.TabIndex = 27
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label17.Location = New System.Drawing.Point(468, 149)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(86, 24)
        Me.Label17.TabIndex = 26
        Me.Label17.Text = "Harga Tiket"
        '
        'cbkodetujuan
        '
        Me.cbkodetujuan.FormattingEnabled = True
        Me.cbkodetujuan.Items.AddRange(New Object() {"1", "2", "3", "4", "5"})
        Me.cbkodetujuan.Location = New System.Drawing.Point(560, 15)
        Me.cbkodetujuan.Margin = New System.Windows.Forms.Padding(4)
        Me.cbkodetujuan.Name = "cbkodetujuan"
        Me.cbkodetujuan.Size = New System.Drawing.Size(99, 32)
        Me.cbkodetujuan.TabIndex = 24
        '
        'txtjam
        '
        Me.txtjam.Location = New System.Drawing.Point(163, 192)
        Me.txtjam.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtjam.Name = "txtjam"
        Me.txtjam.ReadOnly = True
        Me.txtjam.Size = New System.Drawing.Size(147, 29)
        Me.txtjam.TabIndex = 23
        '
        'txttujuan
        '
        Me.txttujuan.Location = New System.Drawing.Point(667, 15)
        Me.txttujuan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txttujuan.Name = "txttujuan"
        Me.txttujuan.ReadOnly = True
        Me.txttujuan.Size = New System.Drawing.Size(436, 29)
        Me.txttujuan.TabIndex = 22
        '
        'txtkelas
        '
        Me.txtkelas.Location = New System.Drawing.Point(559, 55)
        Me.txtkelas.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtkelas.Name = "txtkelas"
        Me.txtkelas.ReadOnly = True
        Me.txtkelas.Size = New System.Drawing.Size(141, 29)
        Me.txtkelas.TabIndex = 21
        '
        'txttahun
        '
        Me.txttahun.Location = New System.Drawing.Point(369, 145)
        Me.txttahun.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txttahun.Name = "txttahun"
        Me.txttahun.ReadOnly = True
        Me.txttahun.Size = New System.Drawing.Size(61, 29)
        Me.txttahun.TabIndex = 20
        '
        'txtbulan
        '
        Me.txtbulan.Location = New System.Drawing.Point(212, 145)
        Me.txtbulan.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtbulan.Name = "txtbulan"
        Me.txtbulan.ReadOnly = True
        Me.txtbulan.Size = New System.Drawing.Size(147, 29)
        Me.txtbulan.TabIndex = 19
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(8, 30)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(80, 24)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "Kode Tiket"
        '
        'txtkode
        '
        Me.txtkode.Location = New System.Drawing.Point(163, 18)
        Me.txtkode.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtkode.Name = "txtkode"
        Me.txtkode.Size = New System.Drawing.Size(135, 29)
        Me.txtkode.TabIndex = 16
        '
        'txttgl
        '
        Me.txttgl.Location = New System.Drawing.Point(161, 145)
        Me.txttgl.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txttgl.Name = "txttgl"
        Me.txttgl.ReadOnly = True
        Me.txttgl.Size = New System.Drawing.Size(44, 29)
        Me.txttgl.TabIndex = 10
        '
        'txtjumlah
        '
        Me.txtjumlah.Location = New System.Drawing.Point(557, 100)
        Me.txtjumlah.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtjumlah.Name = "txtjumlah"
        Me.txtjumlah.Size = New System.Drawing.Size(143, 29)
        Me.txtjumlah.TabIndex = 9
        '
        'txttelepon
        '
        Me.txttelepon.Location = New System.Drawing.Point(163, 106)
        Me.txttelepon.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txttelepon.Name = "txttelepon"
        Me.txttelepon.Size = New System.Drawing.Size(268, 29)
        Me.txttelepon.TabIndex = 8
        '
        'txtnama
        '
        Me.txtnama.Location = New System.Drawing.Point(163, 58)
        Me.txtnama.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtnama.Name = "txtnama"
        Me.txtnama.Size = New System.Drawing.Size(268, 29)
        Me.txtnama.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(463, 106)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(93, 24)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Jumlah Tiket"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(508, 62)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 24)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Kelas"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(500, 18)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 24)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Tujuan"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(5, 196)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(147, 24)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Jam Pemberangkatan"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(5, 151)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 24)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Tgl. Pemberangkatan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(7, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(81, 24)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "No.telepon"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(9, 64)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(109, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Nama Pemesan"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonFace
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(11, 584)
        Me.DataGridView1.Margin = New System.Windows.Forms.Padding(4)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowHeadersVisible = False
        Me.DataGridView1.RowHeadersWidth = 51
        Me.DataGridView1.Size = New System.Drawing.Size(1111, 309)
        Me.DataGridView1.TabIndex = 14
        '
        'btnedit
        '
        Me.btnedit.BackColor = System.Drawing.Color.Transparent
        Me.btnedit.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnedit.Location = New System.Drawing.Point(346, 458)
        Me.btnedit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnedit.Name = "btnedit"
        Me.btnedit.Size = New System.Drawing.Size(67, 34)
        Me.btnedit.TabIndex = 15
        Me.btnedit.Text = "Edit"
        Me.btnedit.UseVisualStyleBackColor = False
        '
        'btndelete
        '
        Me.btndelete.BackColor = System.Drawing.Color.Transparent
        Me.btndelete.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndelete.Location = New System.Drawing.Point(427, 458)
        Me.btndelete.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btndelete.Name = "btndelete"
        Me.btndelete.Size = New System.Drawing.Size(79, 34)
        Me.btndelete.TabIndex = 16
        Me.btndelete.Text = "Hapus"
        Me.btndelete.UseVisualStyleBackColor = False
        '
        'txtcari
        '
        Me.txtcari.Location = New System.Drawing.Point(174, 520)
        Me.txtcari.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtcari.Multiline = True
        Me.txtcari.Name = "txtcari"
        Me.txtcari.Size = New System.Drawing.Size(431, 30)
        Me.txtcari.TabIndex = 28
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Font = New System.Drawing.Font("Trebuchet MS", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(180, 4)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(709, 59)
        Me.Label9.TabIndex = 28
        Me.Label9.Text = "DATA TIKET TRAVEL JAYA ABADI"
        '
        'btntambah
        '
        Me.btntambah.Font = New System.Drawing.Font("Sitka Banner", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btntambah.Location = New System.Drawing.Point(169, 458)
        Me.btntambah.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btntambah.Name = "btntambah"
        Me.btntambah.Size = New System.Drawing.Size(81, 34)
        Me.btntambah.TabIndex = 32
        Me.btntambah.Text = "Pesan"
        Me.btntambah.UseVisualStyleBackColor = True
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.BackColor = System.Drawing.Color.Transparent
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label16.Location = New System.Drawing.Point(378, 499)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 16)
        Me.Label16.TabIndex = 41
        Me.Label16.Text = "CARI"
        '
        'DataPemesanan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Posttest5.My.Resources.Resources.back2
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1136, 906)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.btntambah)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.btndelete)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.btnedit)
        Me.Controls.Add(Me.txtcari)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnclear)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "DataPemesanan"
        Me.Text = "DataPemesanan"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnclear As Button
    Friend WithEvents btnpesan As Button
    Friend WithEvents btnexit As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents bulan As Label
    Friend WithEvents tahun As Label
    Friend WithEvents jml As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents harga As Label
    Friend WithEvents jam As Label
    Friend WithEvents tgl As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents kelas As Label
    Friend WithEvents telepon As Label
    Friend WithEvents tujuan As Label
    Friend WithEvents nama As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents txtharga As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents cbkodetujuan As ComboBox
    Friend WithEvents txtjam As TextBox
    Friend WithEvents txttujuan As TextBox
    Friend WithEvents txtkelas As TextBox
    Friend WithEvents txttahun As TextBox
    Friend WithEvents txtbulan As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtkode As TextBox
    Friend WithEvents txttgl As TextBox
    Friend WithEvents txtjumlah As TextBox
    Friend WithEvents txttelepon As TextBox
    Friend WithEvents txtnama As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnedit As Button
    Friend WithEvents btndelete As Button
    Friend WithEvents txtcari As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents cbpembayaran As ComboBox
    Friend WithEvents Label19 As Label
    Friend WithEvents pembayaran As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents txtpesawat As TextBox
    Friend WithEvents pesawat As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txttotal As TextBox
    Friend WithEvents total As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents btntambah As Button
    Friend WithEvents Label16 As Label
End Class
